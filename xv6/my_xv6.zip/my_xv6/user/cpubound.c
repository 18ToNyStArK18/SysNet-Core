#include "../kernel/types.h"
#include "../kernel/stat.h"
#include "user.h"
#include "../kernel/fcntl.h"

#define NFORK 10
#define IO 5

int main() {
  int n, pid;
  
  for (n = 0; n < NFORK; n++) {
    pid = fork();
    if (pid < 0)
      break;
    if (pid == 0) {
      if (n < IO) {
        // --- I/O-bound process using file operations ---
        char buf[100];
        // Each I/O process needs a unique filename
        char filename[] = "iotest_0.txt";
        filename[7] = '0' + n;

        // Create and write to a file to ensure it exists
        int fd = open(filename, O_CREATE | O_WRONLY);
        if(fd >= 0) {
            write(fd, "io", 2);
        }
        close(fd);

        // Re-open and read from the file to cause I/O sleep
        fd = open(filename, O_RDONLY);
        if(fd >= 0){
            read(fd, buf, sizeof(buf));
        }
        close(fd);
        // --- End of I/O simulation ---
      } else {
        // CPU-bound process
        for (volatile int i = 0; i < 1000000000; i++) {} 
      }
      printf("Process %d finished\n", n);
      exit(0);
    }
  }

  // Parent waits for all children
  for(int i=0; i<NFORK; i++){
    if(wait(0) < 0) {
        break; // Break if no more children
    }
  }

  exit(0);
}
