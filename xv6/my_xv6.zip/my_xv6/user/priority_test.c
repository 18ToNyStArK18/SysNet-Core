#include "../kernel/types.h"
#include "user.h"

int main() {
    printf("Starting priority test...\n");

    if (fork() == 0) { // High-priority child
        set_priority(-10); // Lower nice value = higher priority
        for (long i = 0; i < 50000000; i++) {
            if(i % 10000000 == 0) write(1, "H", 1);
        }
        exit(0);
    }

    if (fork() == 0) { // Low-priority child
        set_priority(10); // Higher nice value = lower priority
        for (long i = 0; i < 50000000; i++) {
            if(i % 10000000 == 0) write(1, "L", 1);
        }
        exit(0);
    }

    wait(0);
    wait(0);
    printf("\nTest finished.\n");
    exit(0);
}
